const Appointments = [];

module.exports = Appointments;
