const jsonQuery = require('json-query');

let data = require('../../providers/providers.json'); // Should be a seperate model

const appointments = require('../models/appointments.model');

module.exports.get_provider_names = function (req, res, next) {
    try{

        let specialty = req.query.specialty; //.toLowerCase();
        let date = req.query.date;
        let minScore = req.query.minScore;

        var result=[];

        var helpers = {
            searchSpeciality: function(arr,special){
            for (let i=0;i<arr.length;i++){
                if(arr[i].toLowerCase()=== special.toLowerCase()) return true;
            }
            return false;
            }
        };
        
        result = jsonQuery('[*score>'+minScore+'& availableDates[**][*from<'+date+'& availableDates[**][*to>'+date+'] & :searchSpeciality(specialties,'+specialty+')]]', {data: data, locals: helpers}).value

        res.send(result);
    }catch{
        res.send('400 (BAD REQUEST)');
    }
};


module.exports.create_appointment = function (req, res, next) {
    try{
        let data = require('../../providers/providers.json');
        // validate and create data object
        if(req.body.name && req.body.date){

            //validate availibility
            let availibility = jsonQuery('[*name='+req.body.name+'& availableDates[**][*from<'+req.body.date+'& availableDates[**][*to>'+req.body.date+']]', {data: data}).value

            if (availibility.length>0){
                appointments.push({
                    name: req.body.name,
                    date: req.body.date
                });
                res.send('200 (OK)');
            }else{
                res.send('400 (BAD REQUEST)');
            }
        }else{
            res.send('400 (BAD REQUEST)');
        }
        
    }catch{
        res.send('400 (BAD REQUEST)');
    }
   
    
};

