const express = require('express');
const router = express.Router();

const appointments_controller = require('../controllers/appointments.controller');

router.get('/', appointments_controller.get_provider_names);

router.post('/', appointments_controller.create_appointment);


module.exports = router;