const express = require('express');
const bodyParser = require('body-parser');

const api = express();

// Import routes
const appointments = require('./routes/appointments.route'); 

// Connect to routes
api.use('/appointments', appointments);

let port = 3500;
api.listen(port, () => {
    console.log('Server is running on port ' + port)
});
